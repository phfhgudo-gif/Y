autoparry v2 by thanpisit - Forge 1.20.1 (client-side), v2.1.0
Menu: press O in game, or Mods > autoparry > Config. Each button flips On / Off.
Built by GitHub Actions. Jar: autoparry-v2-by-thanpisit-2.1.0.jar
