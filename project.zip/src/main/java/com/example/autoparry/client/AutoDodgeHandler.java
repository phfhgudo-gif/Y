package com.example.autoparry.client;

import com.example.autoparry.AutoParryConfig;
import com.example.autoparry.AutoParryMod;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Locale;

/**
 * Client-side auto dodge. Taps Epic Fight's dodge keybind when a hostile mob is close and facing
 * the player. The dodge direction is decided by Epic Fight from the movement keys you hold.
 */
@Mod.EventBusSubscriber(modid = AutoParryMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class AutoDodgeHandler {
    private static boolean enabled = false;
    private static int cooldown = 0;
    private static int holdLeft = 0;
    private static int busy = 0;
    private static KeyMapping forcedKey = null;

    private AutoDodgeHandler() {}

    /** True while a dodge is being performed, so the auto parry does not cancel it. */
    public static boolean isBusy() {
        return busy > 0;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;

        if (player == null || mc.level == null) {
            // Keep the on/off state (shown in the menu); just clear timers and release keys.
            cooldown = 0;
            holdLeft = 0;
            busy = 0;
            release(mc);
            while (AutoParryKeys.DODGE_ENABLE.consumeClick()) { }
            while (AutoParryKeys.DODGE_DISABLE.consumeClick()) { }
            return;
        }

        // Disable is processed last, so if both keys land in one tick, OFF wins.
        while (AutoParryKeys.DODGE_ENABLE.consumeClick()) setEnabled(player, true);
        while (AutoParryKeys.DODGE_DISABLE.consumeClick()) setEnabled(player, false);

        if (cooldown > 0) cooldown--;
        if (busy > 0) busy--;

        // Finish or abort a dodge key press that is in progress.
        if (holdLeft > 0) {
            if (mc.screen != null || !enabled) {
                holdLeft = 0;
                release(mc);
            } else {
                holdLeft--;
                if (holdLeft == 0) release(mc);
            }
            return;
        }

        if (!enabled || mc.screen != null || cooldown > 0 || !player.isAlive() || player.isSpectator()) return;
        if (!ThreatScanner.hasThreat(mc, player, AutoParryConfig.DODGE_RANGE.get())) return;

        KeyMapping dodge = findDodgeKey(mc);
        if (dodge == null) {
            player.displayClientMessage(Component.translatable("message.autoparry.dodge_key_missing"), true);
            cooldown = 100; // do not spam the message
            return;
        }

        KeyMapping.click(dodge.getKey());
        dodge.setDown(true);
        forcedKey = dodge;
        holdLeft = AutoParryConfig.DODGE_HOLD_TICKS.get();
        cooldown = AutoParryConfig.DODGE_COOLDOWN_TICKS.get();
        busy = holdLeft + 8;
    }

    public static boolean isEnabled() {
        return enabled;
    }

    /** Used by the menu screen. */
    public static void setEnabledState(boolean value) {
        enabled = value;
    }

    private static void setEnabled(LocalPlayer player, boolean value) {
        if (enabled == value) return;
        enabled = value;
        player.displayClientMessage(
                Component.translatable(value ? "message.autoparry.dodge_on" : "message.autoparry.dodge_off"), true);
    }

    private static void release(Minecraft mc) {
        if (forcedKey == null) return;
        forcedKey.setDown(KeyUtil.isPhysicallyDown(mc, forcedKey));
        forcedKey = null;
    }

    private static KeyMapping findDodgeKey(Minecraft mc) {
        String override = AutoParryConfig.DODGE_KEY_NAME.get().trim();
        for (KeyMapping km : mc.options.keyMappings) {
            String name = km.getName();
            if (!override.isEmpty()) {
                if (name.equals(override)) return km;
                continue;
            }
            String n = name.toLowerCase(Locale.ROOT);
            String c = km.getCategory().toLowerCase(Locale.ROOT);
            if (n.contains("dodge") && (n.contains("epicfight") || c.contains("epicfight"))) return km;
        }
        return null;
    }
}
