package com.example.autoparry.client;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

/** Simple menu with one On/Off button per feature. Each click flips the state and the label. */
public class AutoParryScreen extends Screen {
    private final Screen parent;
    private Button parryButton;
    private Button dodgeButton;

    public AutoParryScreen(Screen parent) {
        super(Component.translatable("gui.autoparry.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int w = 200;
        int h = 20;
        int x = this.width / 2 - w / 2;
        int y = this.height / 2 - 30;

        parryButton = this.addRenderableWidget(Button.builder(parryLabel(), b -> {
            AutoParryHandler.setEnabledState(!AutoParryHandler.isEnabled());
            b.setMessage(parryLabel());
        }).bounds(x, y, w, h).build());

        dodgeButton = this.addRenderableWidget(Button.builder(dodgeLabel(), b -> {
            AutoDodgeHandler.setEnabledState(!AutoDodgeHandler.isEnabled());
            b.setMessage(dodgeLabel());
        }).bounds(x, y + 28, w, h).build());

        this.addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> this.onClose())
                .bounds(x, y + 66, w, h).build());
    }

    private static Component parryLabel() {
        return label("gui.autoparry.parry", AutoParryHandler.isEnabled());
    }

    private static Component dodgeLabel() {
        return label("gui.autoparry.dodge", AutoDodgeHandler.isEnabled());
    }

    private static Component label(String nameKey, boolean on) {
        Component state = Component.translatable(on ? "gui.autoparry.on" : "gui.autoparry.off")
                .withStyle(on ? ChatFormatting.GREEN : ChatFormatting.RED);
        return Component.translatable(nameKey).append(Component.literal(": ")).append(state);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, this.height / 2 - 55, 0xFFFFFF);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) {
            this.minecraft.setScreen(parent);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
