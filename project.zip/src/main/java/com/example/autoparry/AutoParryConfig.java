package com.example.autoparry;

import net.minecraftforge.common.ForgeConfigSpec;

public final class AutoParryConfig {
    public static final ForgeConfigSpec SPEC;

    // Auto parry
    public static final ForgeConfigSpec.DoubleValue TRIGGER_RANGE;
    public static final ForgeConfigSpec.IntValue HOLD_TICKS;
    public static final ForgeConfigSpec.IntValue GAP_TICKS;
    public static final ForgeConfigSpec.BooleanValue ONLY_WITH_WEAPON;

    // Auto dodge
    public static final ForgeConfigSpec.DoubleValue DODGE_RANGE;
    public static final ForgeConfigSpec.IntValue DODGE_COOLDOWN_TICKS;
    public static final ForgeConfigSpec.IntValue DODGE_HOLD_TICKS;
    public static final ForgeConfigSpec.ConfigValue<String> DODGE_KEY_NAME;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.push("parry");
        TRIGGER_RANGE = b.comment("Distance (blocks) at which a hostile mob facing you triggers guarding.")
                .defineInRange("triggerRange", 4.0D, 1.0D, 10.0D);
        HOLD_TICKS = b.comment("Ticks the guard key is held per pulse (20 ticks = 1 second).")
                .defineInRange("holdTicks", 4, 1, 40);
        GAP_TICKS = b.comment("Ticks the guard key is released between pulses.")
                .defineInRange("gapTicks", 6, 1, 40);
        ONLY_WITH_WEAPON = b.comment("Only auto-guard when holding a weapon (attack damage) or a shield in the off hand.",
                        "Prevents right-click from placing blocks or using items by accident.")
                .define("onlyWithWeapon", true);
        b.pop();

        b.push("dodge");
        DODGE_RANGE = b.comment("Distance (blocks) at which a hostile mob facing you triggers a dodge.")
                .defineInRange("dodgeRange", 2.8D, 1.0D, 8.0D);
        DODGE_COOLDOWN_TICKS = b.comment("Minimum ticks between auto dodges (dodging costs stamina).")
                .defineInRange("dodgeCooldownTicks", 20, 5, 200);
        DODGE_HOLD_TICKS = b.comment("Ticks the Epic Fight dodge key is held for each auto dodge.")
                .defineInRange("dodgeHoldTicks", 2, 1, 10);
        DODGE_KEY_NAME = b.comment("Translation key of Epic Fight's dodge keybind (shown in options.txt as key_<name>).",
                        "Leave empty to auto-detect.")
                .define("dodgeKeyName", "");
        b.pop();

        SPEC = b.build();
    }

    private AutoParryConfig() {}
}
